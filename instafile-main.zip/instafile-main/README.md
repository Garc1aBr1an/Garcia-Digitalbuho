# InstaFile
La forma más rápida de compartir un archivo. Desde donde quieras hacia donde quieras.

## Roadmap
- Cambiar el nombre del parametro
- Hacerlo 100% Responsive
- Reemplazar los espacios en blanco por (_) en los nombres de los archivos
- Permitir cargar multiples archivos al mismo tiempo

## Screenshots
![App Screenshot](./screenshot-1.png)
